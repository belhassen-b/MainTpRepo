import React, {useState} from "react";
import {Button, Form, ListGroup} from "react-bootstrap";
import Todo from "./Todo";

type TodoType = {
    id: number;
    title: string;
    description: string;
    completed: boolean;
    createdOn: Date;
};

const TodoList: React.FC = () => {
    const [todos, setTodos] = useState<TodoType[]>([]);
    const [newTodoTitle, setNewTodoTitle] = useState<string>('');
    const [newTodoDescription, setNewTodoDescription] = useState<string>('');
    const [newTodoCreatedOn, setNewTodoCreatedOn] = useState<Date>(new Date());

    const handleTodoTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setNewTodoTitle(event.target.value);
    };

    const handleTodoDescriptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setNewTodoDescription(event.target.value);
    };

    const handleTodoCreatedOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setNewTodoCreatedOn(new Date(event.target.value));
    };

    const handleAddTodo = () => {
        const newTodo: TodoType = {
            id: Date.now(),
            title: newTodoTitle,
            description: newTodoDescription,
            completed: false,
            createdOn: newTodoCreatedOn,
        };

        setTodos([...todos, newTodo]);
        setNewTodoTitle('');
        setNewTodoDescription('');
        setNewTodoCreatedOn(new Date());
    };

    const handleToggleTodo = (id: number) => {
        const updatedTodos = todos.map(todo => {
            if (todo.id === id) {
                return {...todo, completed: !todo.completed};
            } else {
                return todo;
            }
        });

        setTodos(updatedTodos);
    };

    return (
        <div className="container mt-4">
            <h1 className="mb-4">Todo List</h1>
            <Form className="mb-4">
                <Form.Group controlId="todoTitle">
                    <Form.Label>Todo Title:</Form.Label>
                    <Form.Control type="text" value={newTodoTitle} onChange={handleTodoTitleChange}/>
                </Form.Group>
                <Form.Group controlId="todoDescription">
                    <Form.Label>Todo Description:</Form.Label>
                    <Form.Control type="text" value={newTodoDescription} onChange={handleTodoDescriptionChange}/>
                </Form.Group>
                <Form.Group controlId="todoCreatedOn">
                    <Form.Label>Todo Created On:</Form.Label>
                    <Form.Control type="datetime-local" value={newTodoCreatedOn.toISOString().slice(0, 16)}
                                  onChange={handleTodoCreatedOnChange}/>
                </Form.Group>
                <Button variant="primary" type="button" onClick={handleAddTodo}>
                    Add Todo
                </Button>
            </Form>
            <ListGroup>
                {todos.map(todo => (
                    <Todo key={todo.id} todo={todo} onToggleTodo={() => handleToggleTodo(todo.id)}/>
                ))}
            </ListGroup>
        </div>
    );
};

export default TodoList;