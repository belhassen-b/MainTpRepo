import React from 'react';
import {Button, ListGroup} from 'react-bootstrap';

type TodoProps = {
    todo: {
        id: number;
        title: string;
        description: string;
        completed: boolean;
        createdOn: Date;
    };
    onToggleTodo: () => void;
};

const Todo: React.FC<TodoProps> = ({todo, onToggleTodo}) => {
    const handleToggleTodo = () => {
        onToggleTodo();
    };

    return (
        <ListGroup.Item className="d-flex justify-content-between align-items-start">
            <div>
                <h3>{todo.title}</h3>
                <p>{todo.description}</p>
                <p>{todo.completed ? 'Terminé' : 'Non terminé'}</p>
                <p>Créé le: {todo.createdOn.toLocaleString()}</p>
            </div>
            <div>
                <Button variant={todo.completed ? 'secondary' : 'primary'} onClick={handleToggleTodo}>
                    {todo.completed ? 'Marquer comme non terminé' : 'Marquer comme terminé'}
                </Button>
            </div>
        </ListGroup.Item>
    );
};

export default Todo;