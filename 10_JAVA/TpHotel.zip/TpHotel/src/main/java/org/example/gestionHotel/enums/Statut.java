package org.example.gestionHotel.enums;

public enum Statut {
    STATUT_LIBRE,
    STATUT_OCCUPE,
    STATUT_VALIDEE,
    STATUT_ANNULEE
}
