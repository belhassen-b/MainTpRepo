package org.example;


import org.example.gestionHotel.Hotel;
import org.example.gestionHotel.Ihm;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel("Fethi's House  For Sex Party Bitch");
        Ihm ihm = new Ihm( hotel);
        ihm.lancer();
    }
}