


const baseFlashcards = [
    {
        id: 1,
        question: "Quelle est la date de la prise de la Bastille ?",
        answer: "14 juillet 1789"
    },
    {
        id: 2,
        question: "Quelle est la date de l'armistice ?",
        answer: "11 novembre 1918"
    },
    {
        id: 3,
        question: "Quelle est la date de la prise de la Bastille ?",
        answer: "14 juillet 1789"
    },
    {
        id: 4,
        question: "Comment créer une fonction en javascript ?",
        answer: "function maFonction(){}"
    },
    {
        id: 5,
        question: "Comment créer une variable en javascript ?",
        answer: "let maVariable = 1"
    },
    {
        id: 6,
        question: "Comment créer une constante en javascript ?",
        answer: "const maConstante = 1"
    },
    {
        id: 7,
        question: "Comment installer bootstrap ?",
        answer: "npm install bootstrap"
    }
]

export default baseFlashcards