package org.example.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CrudDialog extends JDialog {

    private InsertDialog insertDialog;

    private JPanel contentPanel;

    private JPanel mainPanel;


    private JButton btnInsert;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnSelect;


    public void closeCrudDialog() {
        setVisible(false);

    }

    public CrudDialog(InsertDialog insertDialog) {
        super(insertDialog, "CRUD Options", true); // Set modal to true
        setSize(400, 300);
        setLocationRelativeTo(insertDialog);
        contentPanel = new JPanel();
        contentPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPanel.setLayout(null);
        getContentPane().add(contentPanel, BorderLayout.CENTER);

        btnInsert = new JButton("Insert");
        btnInsert.setBounds(10, 20, 80, 20);
        contentPanel.add(btnInsert);

        btnUpdate = new JButton("Update");
        btnUpdate.setBounds(10, 50, 80, 20);
        contentPanel.add(btnUpdate);

        btnDelete = new JButton("Delete");
        btnDelete.setBounds(10, 80, 80, 20);
        contentPanel.add(btnDelete);

        btnSelect = new JButton("Select");
        btnSelect.setBounds(10, 110, 80, 20);
        contentPanel.add(btnSelect);

        JPanel jPanelButton = new JPanel();
        jPanelButton.setLayout(new FlowLayout(FlowLayout.RIGHT));
        getContentPane().add(jPanelButton, BorderLayout.SOUTH);

        this.insertDialog = insertDialog;


           btnInsert.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    insertDialog.setVisible(true);
                }
            });

//              btnUpdate.addActionListener(new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent e) {
//                     UpdateDialog updateDialog = new UpdateDialog(insertDialog);
//                     updateDialog.setVisible(true);
//                }
//            });
//
//                 btnDelete.addActionListener(new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent e) {
//                     DeleteDialog deleteDialog = new DeleteDialog(insertDialog);
//                     deleteDialog.setVisible(true);
//
//                 }
//            });
//
//                    btnSelect.addActionListener(new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent e) {
//                     SelectDialog selectDialog = new SelectDialog(insertDialog);
//                     selectDialog.setVisible(true);
//                }
//            });

        JButton jButtonCancel = new JButton("Cancel");
        jPanelButton.add(jButtonCancel);
        jButtonCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeCrudDialog();
            }
        });

    }
}