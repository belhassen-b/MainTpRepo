package org.example.model;



import lombok.*;

@Data

public class Contact {

    private Long id;
    private String name;
    private String number;

}
