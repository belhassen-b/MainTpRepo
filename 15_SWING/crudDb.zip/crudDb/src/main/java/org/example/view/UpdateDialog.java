package org.example.view;

public class UpdateDialog {


    public UpdateDialog(InsertDialog insertDialog) {
    }
}
