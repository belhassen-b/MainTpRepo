export class Article {
    constructor(titre,prix,description){
        this.titre = titre
        this.prix = prix
        this.description = description
    }
    
}